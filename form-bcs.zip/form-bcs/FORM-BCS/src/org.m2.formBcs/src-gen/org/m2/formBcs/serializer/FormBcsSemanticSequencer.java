package org.m2.formBcs.serializer;

import com.google.inject.Inject;
import com.google.inject.Provider;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.serializer.acceptor.ISemanticSequenceAcceptor;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.diagnostic.ISemanticSequencerDiagnosticProvider;
import org.eclipse.xtext.serializer.diagnostic.ISerializationDiagnostic.Acceptor;
import org.eclipse.xtext.serializer.sequencer.AbstractDelegatingSemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.GenericSequencer;
import org.eclipse.xtext.serializer.sequencer.ISemanticNodeProvider.INodesForEObjectProvider;
import org.eclipse.xtext.serializer.sequencer.ISemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;
import org.m2.formBcs.formBcs.Action;
import org.m2.formBcs.formBcs.ActionVariability;
import org.m2.formBcs.formBcs.Activity;
import org.m2.formBcs.formBcs.ActivityApplicationDomain;
import org.m2.formBcs.formBcs.AdaptationPointDesign;
import org.m2.formBcs.formBcs.AdaptationPointModuleDesign;
import org.m2.formBcs.formBcs.AdaptationPointSubsystem;
import org.m2.formBcs.formBcs.AdaptationPoints;
import org.m2.formBcs.formBcs.ApplicationDomain;
import org.m2.formBcs.formBcs.ClassField;
import org.m2.formBcs.formBcs.ClassMethod;
import org.m2.formBcs.formBcs.ClassTarget;
import org.m2.formBcs.formBcs.ConceptualArchitecture;
import org.m2.formBcs.formBcs.ConceptualRealization;
import org.m2.formBcs.formBcs.ConceptualRealizationAdaptationPoint;
import org.m2.formBcs.formBcs.Context;
import org.m2.formBcs.formBcs.ContextDesign;
import org.m2.formBcs.formBcs.ContextModuleDesign;
import org.m2.formBcs.formBcs.DataAccess;
import org.m2.formBcs.formBcs.DataAccessDesign;
import org.m2.formBcs.formBcs.DescriptoModulerDesign;
import org.m2.formBcs.formBcs.Descriptor;
import org.m2.formBcs.formBcs.DescriptorDesign;
import org.m2.formBcs.formBcs.DescriptorDesignSSA;
import org.m2.formBcs.formBcs.Domain;
import org.m2.formBcs.formBcs.Feature;
import org.m2.formBcs.formBcs.FeatureAdaptationPoint;
import org.m2.formBcs.formBcs.FeatureAdaptationPointDesign;
import org.m2.formBcs.formBcs.FeatureBusinessComponent;
import org.m2.formBcs.formBcs.FeatureRealization;
import org.m2.formBcs.formBcs.FeatureVariability;
import org.m2.formBcs.formBcs.FormBcsPackage;
import org.m2.formBcs.formBcs.Horizontal;
import org.m2.formBcs.formBcs.HorizontalAnalysis;
import org.m2.formBcs.formBcs.HorizontalDesign;
import org.m2.formBcs.formBcs.HorizontalDevelopement;
import org.m2.formBcs.formBcs.HorizontalModuleDesign;
import org.m2.formBcs.formBcs.Import;
import org.m2.formBcs.formBcs.Intention;
import org.m2.formBcs.formBcs.IntentionDesign;
import org.m2.formBcs.formBcs.IntentionDesignSSA;
import org.m2.formBcs.formBcs.IntentionModuleDesign;
import org.m2.formBcs.formBcs.Link;
import org.m2.formBcs.formBcs.LinkSSA;
import org.m2.formBcs.formBcs.MessageDesign;
import org.m2.formBcs.formBcs.MessageTask;
import org.m2.formBcs.formBcs.MessageTaskField;
import org.m2.formBcs.formBcs.Model;
import org.m2.formBcs.formBcs.Module;
import org.m2.formBcs.formBcs.ModuleAdaptationPointDesign;
import org.m2.formBcs.formBcs.ModuleDescription;
import org.m2.formBcs.formBcs.ModuleDescriptionDesign;
import org.m2.formBcs.formBcs.ModuleDesign;
import org.m2.formBcs.formBcs.ModuleParameter;
import org.m2.formBcs.formBcs.ModuleRealization;
import org.m2.formBcs.formBcs.ModuleRealizationAdaptationPoint;
import org.m2.formBcs.formBcs.ModuleRefiner;
import org.m2.formBcs.formBcs.ParameterDesign;
import org.m2.formBcs.formBcs.ProcessArchitecture;
import org.m2.formBcs.formBcs.ProcessArchitectureDesign;
import org.m2.formBcs.formBcs.ProcessRealization;
import org.m2.formBcs.formBcs.ProcessRealizationAdaptationPoint;
import org.m2.formBcs.formBcs.ProcessRefiner;
import org.m2.formBcs.formBcs.RealizationDesgn;
import org.m2.formBcs.formBcs.RealizationModuleDesign;
import org.m2.formBcs.formBcs.RealizationSubsystem;
import org.m2.formBcs.formBcs.ReferenceArchitecture;
import org.m2.formBcs.formBcs.ReferenceRealization;
import org.m2.formBcs.formBcs.ReferenceRealizationAdaptationPoint;
import org.m2.formBcs.formBcs.ReusableComponentRealization;
import org.m2.formBcs.formBcs.Rule;
import org.m2.formBcs.formBcs.SSAdaptationDesign;
import org.m2.formBcs.formBcs.SolutionDesign;
import org.m2.formBcs.formBcs.SolutionModuleDesign;
import org.m2.formBcs.formBcs.SolutionSubsystem;
import org.m2.formBcs.formBcs.SubSystem;
import org.m2.formBcs.formBcs.SubSystemRefiner;
import org.m2.formBcs.formBcs.SubsystemArchitecture;
import org.m2.formBcs.formBcs.Task;
import org.m2.formBcs.formBcs.TaskAdaptationPointDesign;
import org.m2.formBcs.formBcs.TaskApplicationDomain;
import org.m2.formBcs.formBcs.TaskVariability;
import org.m2.formBcs.formBcs.Vertical;
import org.m2.formBcs.formBcs.VerticalRefiner;
import org.m2.formBcs.formBcs.methodParameter;
import org.m2.formBcs.services.FormBcsGrammarAccess;

@SuppressWarnings("all")
public class FormBcsSemanticSequencer extends AbstractDelegatingSemanticSequencer {

	@Inject
	private FormBcsGrammarAccess grammarAccess;
	
	public void createSequence(EObject context, EObject semanticObject) {
		if(semanticObject.eClass().getEPackage() == FormBcsPackage.eINSTANCE) switch(semanticObject.eClass().getClassifierID()) {
			case FormBcsPackage.ACTION:
				if(context == grammarAccess.getActionRule()) {
					sequence_Action(context, (Action) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ACTION_VARIABILITY:
				if(context == grammarAccess.getActionVariabilityRule()) {
					sequence_ActionVariability(context, (ActionVariability) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ACTIVITY:
				if(context == grammarAccess.getActivityRule()) {
					sequence_Activity(context, (Activity) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ACTIVITY_APPLICATION_DOMAIN:
				if(context == grammarAccess.getActivityApplicationDomainRule()) {
					sequence_ActivityApplicationDomain(context, (ActivityApplicationDomain) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ADAPTATION_POINT_DESIGN:
				if(context == grammarAccess.getAdaptationPointDesignRule()) {
					sequence_AdaptationPointDesign(context, (AdaptationPointDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ADAPTATION_POINT_MODULE_DESIGN:
				if(context == grammarAccess.getAdaptationPointModuleDesignRule()) {
					sequence_AdaptationPointModuleDesign(context, (AdaptationPointModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ADAPTATION_POINT_SUBSYSTEM:
				if(context == grammarAccess.getAdaptationPointSubsystemRule()) {
					sequence_AdaptationPointSubsystem(context, (AdaptationPointSubsystem) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.ADAPTATION_POINTS:
				if(context == grammarAccess.getAdaptationPointsRule()) {
					sequence_AdaptationPoints(context, (AdaptationPoints) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.APPLICATION_DOMAIN:
				if(context == grammarAccess.getApplicationDomainRule()) {
					sequence_ApplicationDomain(context, (ApplicationDomain) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.BOOLEAN:
				if(context == grammarAccess.getBooleanRule()) {
					sequence_Boolean(context, (org.m2.formBcs.formBcs.Boolean) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CLASS:
				if(context == grammarAccess.getClassRule()) {
					sequence_Class(context, (org.m2.formBcs.formBcs.Class) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CLASS_FIELD:
				if(context == grammarAccess.getClassFieldRule() ||
				   context == grammarAccess.getMemberRule()) {
					sequence_ClassField(context, (ClassField) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CLASS_METHOD:
				if(context == grammarAccess.getClassMethodRule() ||
				   context == grammarAccess.getMemberRule()) {
					sequence_ClassMethod(context, (ClassMethod) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CLASS_TARGET:
				if(context == grammarAccess.getClassTargetRule()) {
					sequence_ClassTarget(context, (ClassTarget) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONCEPTUAL_ARCHITECTURE:
				if(context == grammarAccess.getConceptualArchitectureRule() ||
				   context == grammarAccess.getSolutionRule()) {
					sequence_ConceptualArchitecture(context, (ConceptualArchitecture) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONCEPTUAL_REALIZATION:
				if(context == grammarAccess.getConceptualRealizationRule()) {
					sequence_ConceptualRealization(context, (ConceptualRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONCEPTUAL_REALIZATION_ADAPTATION_POINT:
				if(context == grammarAccess.getConceptualRealizationAdaptationPointRule()) {
					sequence_ConceptualRealizationAdaptationPoint(context, (ConceptualRealizationAdaptationPoint) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONTEXT:
				if(context == grammarAccess.getContextRule()) {
					sequence_Context(context, (Context) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONTEXT_DESIGN:
				if(context == grammarAccess.getContextDesignRule()) {
					sequence_ContextDesign(context, (ContextDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.CONTEXT_MODULE_DESIGN:
				if(context == grammarAccess.getContextModuleDesignRule()) {
					sequence_ContextModuleDesign(context, (ContextModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DATA_ACCESS:
				if(context == grammarAccess.getDataAccessRule()) {
					sequence_DataAccess(context, (DataAccess) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DATA_ACCESS_DESIGN:
				if(context == grammarAccess.getDataAccessDesignRule()) {
					sequence_DataAccessDesign(context, (DataAccessDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DESCRIPTO_MODULER_DESIGN:
				if(context == grammarAccess.getDescriptoModulerDesignRule()) {
					sequence_DescriptoModulerDesign(context, (DescriptoModulerDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DESCRIPTOR:
				if(context == grammarAccess.getDescriptorRule()) {
					sequence_Descriptor(context, (Descriptor) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DESCRIPTOR_DESIGN:
				if(context == grammarAccess.getDescriptorDesignRule()) {
					sequence_DescriptorDesign(context, (DescriptorDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DESCRIPTOR_DESIGN_SSA:
				if(context == grammarAccess.getDescriptorDesignSSARule()) {
					sequence_DescriptorDesignSSA(context, (DescriptorDesignSSA) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.DOMAIN:
				if(context == grammarAccess.getDomainRule()) {
					sequence_Domain(context, (Domain) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE:
				if(context == grammarAccess.getFeatureRule() ||
				   context == grammarAccess.getSolutionRule()) {
					sequence_Feature(context, (Feature) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE_ADAPTATION_POINT:
				if(context == grammarAccess.getFeatureAdaptationPointRule()) {
					sequence_FeatureAdaptationPoint(context, (FeatureAdaptationPoint) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE_ADAPTATION_POINT_DESIGN:
				if(context == grammarAccess.getFeatureAdaptationPointDesignRule()) {
					sequence_FeatureAdaptationPointDesign(context, (FeatureAdaptationPointDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE_BUSINESS_COMPONENT:
				if(context == grammarAccess.getFeatureBusinessComponentRule()) {
					sequence_FeatureBusinessComponent(context, (FeatureBusinessComponent) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE_REALIZATION:
				if(context == grammarAccess.getFeatureRealizationRule()) {
					sequence_FeatureRealization(context, (FeatureRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.FEATURE_VARIABILITY:
				if(context == grammarAccess.getFeatureVariabilityRule()) {
					sequence_FeatureVariability(context, (FeatureVariability) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.HORIZONTAL:
				if(context == grammarAccess.getHorizontalRule()) {
					sequence_Horizontal(context, (Horizontal) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.HORIZONTAL_ANALYSIS:
				if(context == grammarAccess.getHorizontalAnalysisRule()) {
					sequence_HorizontalAnalysis(context, (HorizontalAnalysis) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.HORIZONTAL_DESIGN:
				if(context == grammarAccess.getHorizontalDesignRule()) {
					sequence_HorizontalDesign(context, (HorizontalDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.HORIZONTAL_DEVELOPEMENT:
				if(context == grammarAccess.getHorizontalDevelopementRule()) {
					sequence_HorizontalDevelopement(context, (HorizontalDevelopement) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.HORIZONTAL_MODULE_DESIGN:
				if(context == grammarAccess.getHorizontalModuleDesignRule()) {
					sequence_HorizontalModuleDesign(context, (HorizontalModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.IMPORT:
				if(context == grammarAccess.getImportRule()) {
					sequence_Import(context, (Import) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.INTENTION:
				if(context == grammarAccess.getIntentionRule()) {
					sequence_Intention(context, (Intention) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.INTENTION_DESIGN:
				if(context == grammarAccess.getIntentionDesignRule()) {
					sequence_IntentionDesign(context, (IntentionDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.INTENTION_DESIGN_SSA:
				if(context == grammarAccess.getIntentionDesignSSARule()) {
					sequence_IntentionDesignSSA(context, (IntentionDesignSSA) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.INTENTION_MODULE_DESIGN:
				if(context == grammarAccess.getIntentionModuleDesignRule()) {
					sequence_IntentionModuleDesign(context, (IntentionModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.LINK:
				if(context == grammarAccess.getLinkRule()) {
					sequence_Link(context, (Link) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.LINK_SSA:
				if(context == grammarAccess.getLinkSSARule()) {
					sequence_LinkSSA(context, (LinkSSA) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MESSAGE_DESIGN:
				if(context == grammarAccess.getMessageDesignRule()) {
					sequence_MessageDesign(context, (MessageDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MESSAGE_TASK:
				if(context == grammarAccess.getMessageTaskRule()) {
					sequence_MessageTask(context, (MessageTask) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MESSAGE_TASK_FIELD:
				if(context == grammarAccess.getMessageTaskFieldRule()) {
					sequence_MessageTaskField(context, (MessageTaskField) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODEL:
				if(context == grammarAccess.getModelRule()) {
					sequence_Model(context, (Model) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE:
				if(context == grammarAccess.getModuleRule() ||
				   context == grammarAccess.getSolutionRule()) {
					sequence_Module(context, (Module) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_ADAPTATION_POINT_DESIGN:
				if(context == grammarAccess.getModuleAdaptationPointDesignRule()) {
					sequence_ModuleAdaptationPointDesign(context, (ModuleAdaptationPointDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_DESCRIPTION:
				if(context == grammarAccess.getModuleDescriptionRule()) {
					sequence_ModuleDescription(context, (ModuleDescription) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_DESCRIPTION_DESIGN:
				if(context == grammarAccess.getModuleDescriptionDesignRule()) {
					sequence_ModuleDescriptionDesign(context, (ModuleDescriptionDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_DESIGN:
				if(context == grammarAccess.getModuleDesignRule()) {
					sequence_ModuleDesign(context, (ModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_PARAMETER:
				if(context == grammarAccess.getModuleParameterRule()) {
					sequence_ModuleParameter(context, (ModuleParameter) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_REALIZATION:
				if(context == grammarAccess.getModuleRealizationRule()) {
					sequence_ModuleRealization(context, (ModuleRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_REALIZATION_ADAPTATION_POINT:
				if(context == grammarAccess.getModuleRealizationAdaptationPointRule()) {
					sequence_ModuleRealizationAdaptationPoint(context, (ModuleRealizationAdaptationPoint) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.MODULE_REFINER:
				if(context == grammarAccess.getModuleRefinerRule()) {
					sequence_ModuleRefiner(context, (ModuleRefiner) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PARAMETER_DESIGN:
				if(context == grammarAccess.getParameterDesignRule()) {
					sequence_ParameterDesign(context, (ParameterDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS:
				if(context == grammarAccess.getProcessRule()) {
					sequence_Process(context, (org.m2.formBcs.formBcs.Process) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS_ARCHITECTURE:
				if(context == grammarAccess.getProcessArchitectureRule() ||
				   context == grammarAccess.getSolutionRule()) {
					sequence_ProcessArchitecture(context, (ProcessArchitecture) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS_ARCHITECTURE_DESIGN:
				if(context == grammarAccess.getProcessArchitectureDesignRule()) {
					sequence_ProcessArchitectureDesign(context, (ProcessArchitectureDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS_REALIZATION:
				if(context == grammarAccess.getProcessRealizationRule()) {
					sequence_ProcessRealization(context, (ProcessRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS_REALIZATION_ADAPTATION_POINT:
				if(context == grammarAccess.getProcessRealizationAdaptationPointRule()) {
					sequence_ProcessRealizationAdaptationPoint(context, (ProcessRealizationAdaptationPoint) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.PROCESS_REFINER:
				if(context == grammarAccess.getProcessRefinerRule()) {
					sequence_ProcessRefiner(context, (ProcessRefiner) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REALIZATION_DESGN:
				if(context == grammarAccess.getRealizationDesgnRule()) {
					sequence_RealizationDesgn(context, (RealizationDesgn) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REALIZATION_MODULE_DESIGN:
				if(context == grammarAccess.getRealizationModuleDesignRule()) {
					sequence_RealizationModuleDesign(context, (RealizationModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REALIZATION_SUBSYSTEM:
				if(context == grammarAccess.getRealizationSubsystemRule()) {
					sequence_RealizationSubsystem(context, (RealizationSubsystem) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REFERENCE_ARCHITECTURE:
				if(context == grammarAccess.getReferenceArchitectureRule() ||
				   context == grammarAccess.getSolutionRule()) {
					sequence_ReferenceArchitecture(context, (ReferenceArchitecture) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REFERENCE_REALIZATION:
				if(context == grammarAccess.getReferenceRealizationRule()) {
					sequence_ReferenceRealization(context, (ReferenceRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REFERENCE_REALIZATION_ADAPTATION_POINT:
				if(context == grammarAccess.getReferenceRealizationAdaptationPointRule()) {
					sequence_ReferenceRealizationAdaptationPoint(context, (ReferenceRealizationAdaptationPoint) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.REUSABLE_COMPONENT_REALIZATION:
				if(context == grammarAccess.getReusableComponentRealizationRule()) {
					sequence_ReusableComponentRealization(context, (ReusableComponentRealization) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.RULE:
				if(context == grammarAccess.getRuleRule()) {
					sequence_Rule(context, (Rule) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SS_ADAPTATION_DESIGN:
				if(context == grammarAccess.getSSAdaptationDesignRule()) {
					sequence_SSAdaptationDesign(context, (SSAdaptationDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SOLUTION_DESIGN:
				if(context == grammarAccess.getSolutionDesignRule()) {
					sequence_SolutionDesign(context, (SolutionDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SOLUTION_MODULE_DESIGN:
				if(context == grammarAccess.getSolutionModuleDesignRule()) {
					sequence_SolutionModuleDesign(context, (SolutionModuleDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SOLUTION_SUBSYSTEM:
				if(context == grammarAccess.getSolutionSubsystemRule()) {
					sequence_SolutionSubsystem(context, (SolutionSubsystem) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SUB_SYSTEM:
				if(context == grammarAccess.getSubSystemRule()) {
					sequence_SubSystem(context, (SubSystem) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SUB_SYSTEM_REFINER:
				if(context == grammarAccess.getSubSystemRefinerRule()) {
					sequence_SubSystemRefiner(context, (SubSystemRefiner) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.SUBSYSTEM_ARCHITECTURE:
				if(context == grammarAccess.getSubsystemArchitectureRule()) {
					sequence_SubsystemArchitecture(context, (SubsystemArchitecture) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.TASK:
				if(context == grammarAccess.getTaskRule()) {
					sequence_Task(context, (Task) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.TASK_ADAPTATION_POINT_DESIGN:
				if(context == grammarAccess.getTaskAdaptationPointDesignRule()) {
					sequence_TaskAdaptationPointDesign(context, (TaskAdaptationPointDesign) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.TASK_APPLICATION_DOMAIN:
				if(context == grammarAccess.getTaskApplicationDomainRule()) {
					sequence_TaskApplicationDomain(context, (TaskApplicationDomain) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.TASK_VARIABILITY:
				if(context == grammarAccess.getTaskVariabilityRule()) {
					sequence_TaskVariability(context, (TaskVariability) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.VERTICAL:
				if(context == grammarAccess.getVerticalRule()) {
					sequence_Vertical(context, (Vertical) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.VERTICAL_REFINER:
				if(context == grammarAccess.getVerticalRefinerRule()) {
					sequence_VerticalRefiner(context, (VerticalRefiner) semanticObject); 
					return; 
				}
				else break;
			case FormBcsPackage.METHOD_PARAMETER:
				if(context == grammarAccess.getMethodParameterRule()) {
					sequence_methodParameter(context, (methodParameter) semanticObject); 
					return; 
				}
				else break;
			}
		if (errorAcceptor != null) errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Constraint:
	 *     (name=ID (actions+=[Action|ID] actions+=[Action|ID]*)?)
	 */
	protected void sequence_ActionVariability(EObject context, ActionVariability semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     name=ID
	 */
	protected void sequence_Action(EObject context, Action semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.ACTION__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.ACTION__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getActionAccess().getNameIDTerminalRuleCall_2_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         targetActivity=[Activity|ID] 
	 *         (common+=[Task|ID] common+=[Task|ID]*)? 
	 *         (optional+=[Task|ID] optional+=[Task|ID]*)? 
	 *         (variabilities+=[TaskVariability|ID] variabilities+=[TaskVariability|ID]*)?
	 *     )
	 */
	protected void sequence_ActivityApplicationDomain(EObject context, ActivityApplicationDomain semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         (common+=[Task|ID] common+=[Task|ID]*)? 
	 *         (optional+=[Task|ID] optional+=[Task|ID]*)? 
	 *         (variabilities+=[TaskVariability|ID] tasks+=[TaskVariability|ID]*)?
	 *     )
	 */
	protected void sequence_Activity(EObject context, Activity semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (adaptationpoint+=TaskAdaptationPointDesign adaptationpoint+=TaskAdaptationPointDesign*)?
	 */
	protected void sequence_AdaptationPointDesign(EObject context, AdaptationPointDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (adaptationpoint+=ModuleAdaptationPointDesign adaptationpoint+=ModuleAdaptationPointDesign*)?
	 */
	protected void sequence_AdaptationPointModuleDesign(EObject context, AdaptationPointModuleDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (adaptationpoints+=SSAdaptationDesign adaptationpoints+=SSAdaptationDesign*)?
	 */
	protected void sequence_AdaptationPointSubsystem(EObject context, AdaptationPointSubsystem semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (adaptationpoints+=[FeatureAdaptationPoint|ID] adaptationpoints+=[FeatureAdaptationPoint|ID]*)?
	 */
	protected void sequence_AdaptationPoints(EObject context, AdaptationPoints semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         targetFeature=[Feature|ID] 
	 *         (common+=[Feature|ID] common+=[Feature|ID]*)? 
	 *         (optional+=[Feature|ID] optional+=[Feature|ID]*)? 
	 *         (variabilities+=[FeatureVariability|ID] variabilities+=[FeatureVariability|ID]*)?
	 *     )
	 */
	protected void sequence_ApplicationDomain(EObject context, ApplicationDomain semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (value='true' | value='false')
	 */
	protected void sequence_Boolean(EObject context, org.m2.formBcs.formBcs.Boolean semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (type=[Class|ID] name=ID)
	 */
	protected void sequence_ClassField(EObject context, ClassField semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MEMBER__TYPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MEMBER__TYPE));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MEMBER__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MEMBER__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getClassFieldAccess().getTypeClassIDTerminalRuleCall_0_0_1(), semanticObject.getType());
		feeder.accept(grammarAccess.getClassFieldAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (type=[Class|ID] name=ID (params+=methodParameter params+=methodParameter*)?)
	 */
	protected void sequence_ClassMethod(EObject context, ClassMethod semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     ((classes+=[Class|ID] classes+=[Class|ID]*)?)
	 */
	protected void sequence_ClassTarget(EObject context, ClassTarget semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID superType=[Class|ID]? members+=Member*)
	 */
	protected void sequence_Class(EObject context, org.m2.formBcs.formBcs.Class semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID (subsystems+=[SubSystem|ID] subsystems+=[SubSystem|ID]*)? (links+=[Link|ID] links+=[Link|ID])?)
	 */
	protected void sequence_ConceptualArchitecture(EObject context, ConceptualArchitecture semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID subsystem=[SubSystem|ID] (subsystems+=[SubSystem|ID] subsystems+=[SubSystem|ID]*)?)
	 */
	protected void sequence_ConceptualRealizationAdaptationPoint(EObject context, ConceptualRealizationAdaptationPoint semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         solution=[ConceptualArchitecture|ID] 
	 *         (adaptationpoints+=[ConceptualRealizationAdaptationPoint|ID] adaptationpoints+=[ConceptualRealizationAdaptationPoint|ID]*)?
	 *     )
	 */
	protected void sequence_ConceptualRealization(EObject context, ConceptualRealization semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (domain=[Domain|ID] (processes+=[Process|ID] processes+=[Process|ID]*)*)
	 */
	protected void sequence_ContextDesign(EObject context, ContextDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (domain=[Domain|ID] (processes+=[Task|ID] processes+=[Task|ID]*)*)
	 */
	protected void sequence_ContextModuleDesign(EObject context, ContextModuleDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID domain=[Domain|ID] (processes+=[Process|ID] processes+=[Process|ID]*)? (rules+=[Rule|ID] rules+=[Rule|ID]*)?)
	 */
	protected void sequence_Context(EObject context, Context semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (task=[Task|ID] classe=[Class|ID])
	 */
	protected void sequence_DataAccessDesign(EObject context, DataAccessDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS_DESIGN__TASK) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS_DESIGN__TASK));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS_DESIGN__CLASSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS_DESIGN__CLASSE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDataAccessDesignAccess().getTaskTaskIDTerminalRuleCall_1_0_1(), semanticObject.getTask());
		feeder.accept(grammarAccess.getDataAccessDesignAccess().getClasseClassIDTerminalRuleCall_3_0_1(), semanticObject.getClasse());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID task=[Task|ID] classe=[Class|ID] body=STRING)
	 */
	protected void sequence_DataAccess(EObject context, DataAccess semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__TASK) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__TASK));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__CLASSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__CLASSE));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__BODY) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DATA_ACCESS__BODY));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDataAccessAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getDataAccessAccess().getTaskTaskIDTerminalRuleCall_4_0_1(), semanticObject.getTask());
		feeder.accept(grammarAccess.getDataAccessAccess().getClasseClassIDTerminalRuleCall_6_0_1(), semanticObject.getClasse());
		feeder.accept(grammarAccess.getDataAccessAccess().getBodySTRINGTerminalRuleCall_8_0(), semanticObject.getBody());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (intention=IntentionModuleDesign context=ContextModuleDesign)
	 */
	protected void sequence_DescriptoModulerDesign(EObject context, DescriptoModulerDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTO_MODULER_DESIGN__INTENTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTO_MODULER_DESIGN__INTENTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTO_MODULER_DESIGN__CONTEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTO_MODULER_DESIGN__CONTEXT));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDescriptoModulerDesignAccess().getIntentionIntentionModuleDesignParserRuleCall_2_0(), semanticObject.getIntention());
		feeder.accept(grammarAccess.getDescriptoModulerDesignAccess().getContextContextModuleDesignParserRuleCall_4_0(), semanticObject.getContext());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (intention=IntentionDesignSSA context=[Context|ID])
	 */
	protected void sequence_DescriptorDesignSSA(EObject context, DescriptorDesignSSA semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN_SSA__INTENTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN_SSA__INTENTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN_SSA__CONTEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN_SSA__CONTEXT));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDescriptorDesignSSAAccess().getIntentionIntentionDesignSSAParserRuleCall_2_0(), semanticObject.getIntention());
		feeder.accept(grammarAccess.getDescriptorDesignSSAAccess().getContextContextIDTerminalRuleCall_4_0_1(), semanticObject.getContext());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (intention=IntentionDesign context=ContextDesign)
	 */
	protected void sequence_DescriptorDesign(EObject context, DescriptorDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN__INTENTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN__INTENTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN__CONTEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR_DESIGN__CONTEXT));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDescriptorDesignAccess().getIntentionIntentionDesignParserRuleCall_2_0(), semanticObject.getIntention());
		feeder.accept(grammarAccess.getDescriptorDesignAccess().getContextContextDesignParserRuleCall_4_0(), semanticObject.getContext());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID intention=[Intention|ID] context=[Context|ID])
	 */
	protected void sequence_Descriptor(EObject context, Descriptor semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__INTENTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__INTENTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__CONTEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.DESCRIPTOR__CONTEXT));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getDescriptorAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getDescriptorAccess().getIntentionIntentionIDTerminalRuleCall_4_0_1(), semanticObject.getIntention());
		feeder.accept(grammarAccess.getDescriptorAccess().getContextContextIDTerminalRuleCall_6_0_1(), semanticObject.getContext());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID action=[Activity|ID] (classes+=[Class|ID] classes+=[Class|ID]*)? precision=STRING)
	 */
	protected void sequence_Domain(EObject context, Domain semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         adaptationpoint+='(' 
	 *         feature=[Feature|ID] 
	 *         features+=[Feature|ID] 
	 *         features+=[Feature|ID]* 
	 *         (adaptationpoint+='(' feature=[Feature|ID] features+=[Feature|ID] features+=[Feature|ID]*)*
	 *     )?
	 */
	protected void sequence_FeatureAdaptationPointDesign(EObject context, FeatureAdaptationPointDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID feature=[Feature|ID] (features+=[Feature|ID] features+=[Feature|ID]*)?)
	 */
	protected void sequence_FeatureAdaptationPoint(EObject context, FeatureAdaptationPoint semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID descriptor=[Descriptor|ID] realization=[FeatureRealization|ID])
	 */
	protected void sequence_FeatureBusinessComponent(EObject context, FeatureBusinessComponent semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__DESCRIPTOR) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__DESCRIPTOR));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__REALIZATION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_BUSINESS_COMPONENT__REALIZATION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getFeatureBusinessComponentAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getFeatureBusinessComponentAccess().getDescriptorDescriptorIDTerminalRuleCall_4_0_1(), semanticObject.getDescriptor());
		feeder.accept(grammarAccess.getFeatureBusinessComponentAccess().getRealizationFeatureRealizationIDTerminalRuleCall_6_0_1(), semanticObject.getRealization());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID solution=[Feature|ID] adaptationpoints=AdaptationPoints)
	 */
	protected void sequence_FeatureRealization(EObject context, FeatureRealization semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.FEATURE_REALIZATION__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getFeatureRealizationAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getFeatureRealizationAccess().getSolutionFeatureIDTerminalRuleCall_4_0_1(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getFeatureRealizationAccess().getAdaptationpointsAdaptationPointsParserRuleCall_5_0(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID features+=[Feature|ID] features+=[Feature|ID]*)
	 */
	protected void sequence_FeatureVariability(EObject context, FeatureVariability semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         verb=[Activity|ID] 
	 *         (classes+=[Class|ID] classes+=[Class|ID]*)? 
	 *         (common+=[Feature|ID] common+=[Feature|ID]*)? 
	 *         (optional+=[Feature|ID] optional+=[Feature|ID]*)? 
	 *         (variabilities+=[FeatureVariability|ID] variabilities+=[FeatureVariability|ID]*)? 
	 *         (generalization+=[Feature|ID] generalization+=[Feature|ID]*)?
	 *     )
	 */
	protected void sequence_Feature(EObject context, Feature semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     feature=[FeatureBusinessComponent|ID]
	 */
	protected void sequence_HorizontalAnalysis(EObject context, HorizontalAnalysis semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_ANALYSIS__FEATURE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_ANALYSIS__FEATURE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getHorizontalAnalysisAccess().getFeatureFeatureBusinessComponentIDTerminalRuleCall_1_0_1(), semanticObject.getFeature());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (fbc=[FeatureBusinessComponent|ID] targetName=ID)
	 */
	protected void sequence_HorizontalDesign(EObject context, HorizontalDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DESIGN__FBC) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DESIGN__FBC));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DESIGN__TARGET_NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DESIGN__TARGET_NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getHorizontalDesignAccess().getFbcFeatureBusinessComponentIDTerminalRuleCall_3_0_1(), semanticObject.getFbc());
		feeder.accept(grammarAccess.getHorizontalDesignAccess().getTargetNameIDTerminalRuleCall_5_0(), semanticObject.getTargetName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (ssbc=[SubsystemArchitecture|ID] targetName=ID)
	 */
	protected void sequence_HorizontalDevelopement(EObject context, HorizontalDevelopement semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DEVELOPEMENT__SSBC) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DEVELOPEMENT__SSBC));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DEVELOPEMENT__TARGET_NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_DEVELOPEMENT__TARGET_NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getHorizontalDevelopementAccess().getSsbcSubsystemArchitectureIDTerminalRuleCall_3_0_1(), semanticObject.getSsbc());
		feeder.accept(grammarAccess.getHorizontalDevelopementAccess().getTargetNameIDTerminalRuleCall_5_0(), semanticObject.getTargetName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (pass=[ProcessArchitectureDesign|ID] targetName=ID solutionName=ID)
	 */
	protected void sequence_HorizontalModuleDesign(EObject context, HorizontalModuleDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__PASS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__PASS));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__TARGET_NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__TARGET_NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__SOLUTION_NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.HORIZONTAL_MODULE_DESIGN__SOLUTION_NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getHorizontalModuleDesignAccess().getPassProcessArchitectureDesignIDTerminalRuleCall_3_0_1(), semanticObject.getPass());
		feeder.accept(grammarAccess.getHorizontalModuleDesignAccess().getTargetNameIDTerminalRuleCall_5_0(), semanticObject.getTargetName());
		feeder.accept(grammarAccess.getHorizontalModuleDesignAccess().getSolutionNameIDTerminalRuleCall_7_0(), semanticObject.getSolutionName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (tosave+=HorizontalAnalysis* designs+=HorizontalDesign* developement+=HorizontalDevelopement* moduleDesigns+=HorizontalModuleDesign*)
	 */
	protected void sequence_Horizontal(EObject context, Horizontal semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     importedNamespace=QualifiedNameWithWildcard
	 */
	protected void sequence_Import(EObject context, Import semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.IMPORT__IMPORTED_NAMESPACE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.IMPORT__IMPORTED_NAMESPACE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0(), semanticObject.getImportedNamespace());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (action=[Activity|ID] domain=[Domain|ID])
	 */
	protected void sequence_IntentionDesignSSA(EObject context, IntentionDesignSSA semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.INTENTION_DESIGN_SSA__ACTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.INTENTION_DESIGN_SSA__ACTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.INTENTION_DESIGN_SSA__DOMAIN) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.INTENTION_DESIGN_SSA__DOMAIN));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getIntentionDesignSSAAccess().getActionActivityIDTerminalRuleCall_3_0_1(), semanticObject.getAction());
		feeder.accept(grammarAccess.getIntentionDesignSSAAccess().getDomainDomainIDTerminalRuleCall_6_0_1(), semanticObject.getDomain());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (action=[Activity|ID] (classes+=[Class|ID] classes+=[Class|ID]*)?)
	 */
	protected void sequence_IntentionDesign(EObject context, IntentionDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (action=[Activity|ID] target=[Task|ID])
	 */
	protected void sequence_IntentionModuleDesign(EObject context, IntentionModuleDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.INTENTION_MODULE_DESIGN__ACTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.INTENTION_MODULE_DESIGN__ACTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.INTENTION_MODULE_DESIGN__TARGET) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.INTENTION_MODULE_DESIGN__TARGET));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getIntentionModuleDesignAccess().getActionActivityIDTerminalRuleCall_3_0_1(), semanticObject.getAction());
		feeder.accept(grammarAccess.getIntentionModuleDesignAccess().getTargetTaskIDTerminalRuleCall_5_0_1(), semanticObject.getTarget());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID action=[Activity|ID] (interest=ClassTarget | interest=[Domain|ID]))
	 */
	protected void sequence_Intention(EObject context, Intention semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (subsystem1=[SubSystem|ID] subsystem2=[SubSystem|ID])?
	 */
	protected void sequence_LinkSSA(EObject context, LinkSSA semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.LINK_SSA__SUBSYSTEM1) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.LINK_SSA__SUBSYSTEM1));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.LINK_SSA__SUBSYSTEM2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.LINK_SSA__SUBSYSTEM2));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getLinkSSAAccess().getSubsystem1SubSystemIDTerminalRuleCall_1_0_0_1(), semanticObject.getSubsystem1());
		feeder.accept(grammarAccess.getLinkSSAAccess().getSubsystem2SubSystemIDTerminalRuleCall_1_2_0_1(), semanticObject.getSubsystem2());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID (subsystem1=[SubSystem|ID] subsystem2=[SubSystem|ID])?)
	 */
	protected void sequence_Link(EObject context, Link semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     message=MessageTaskField
	 */
	protected void sequence_MessageDesign(EObject context, MessageDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MESSAGE_DESIGN__MESSAGE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MESSAGE_DESIGN__MESSAGE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getMessageDesignAccess().getMessageMessageTaskFieldParserRuleCall_1_0(), semanticObject.getMessage());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (task1=[Task|ID]? task2=[Task|ID]?)
	 */
	protected void sequence_MessageTaskField(EObject context, MessageTaskField semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID field=MessageTaskField body=STRING reply=Boolean?)
	 */
	protected void sequence_MessageTask(EObject context, MessageTask semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         imports+=Import* 
	 *         (
	 *             definitions+=Feature | 
	 *             definitions+=Link | 
	 *             definitions+=Action | 
	 *             definitions+=Task | 
	 *             definitions+=FeatureVariability | 
	 *             definitions+=ActionVariability | 
	 *             definitions+=Activity | 
	 *             definitions+=SubSystem | 
	 *             definitions+=ConceptualArchitecture | 
	 *             definitions+=TaskVariability | 
	 *             definitions+=Class | 
	 *             definitions+=DataAccess | 
	 *             definitions+=ProcessArchitecture | 
	 *             definitions+=MessageTask | 
	 *             definitions+=Module | 
	 *             definitions+=ModuleParameter | 
	 *             definitions+=ModuleDescription | 
	 *             definitions+=Process | 
	 *             definitions+=Rule | 
	 *             definitions+=Context | 
	 *             definitions+=Domain | 
	 *             definitions+=Descriptor | 
	 *             definitions+=ReferenceArchitecture | 
	 *             definitions+=Intention | 
	 *             definitions+=FeatureAdaptationPoint | 
	 *             definitions+=FeatureRealization | 
	 *             definitions+=ConceptualRealization | 
	 *             definitions+=ConceptualRealizationAdaptationPoint | 
	 *             definitions+=ProcessRealization | 
	 *             definitions+=ProcessRealizationAdaptationPoint | 
	 *             definitions+=ModuleRealization | 
	 *             definitions+=ModuleRealizationAdaptationPoint | 
	 *             definitions+=ReusableComponentRealization | 
	 *             definitions+=ReferenceRealization | 
	 *             definitions+=ReferenceRealizationAdaptationPoint | 
	 *             definitions+=FeatureBusinessComponent | 
	 *             definitions+=SubsystemArchitecture | 
	 *             definitions+=ProcessArchitectureDesign | 
	 *             definitions+=ModuleDesign
	 *         )* 
	 *         horizontal=Horizontal? 
	 *         vertical=Vertical?
	 *     )?
	 */
	protected void sequence_Model(EObject context, Model semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (module=[Module|ID] modules+=[Module|ID] modules+=[Module|ID]*)
	 */
	protected void sequence_ModuleAdaptationPointDesign(EObject context, ModuleAdaptationPointDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (task=[Task|ID] (included+=[Module|ID] included+=[Module|ID]*)? (required+=[Module|ID] required+=[Module|ID]*)?)
	 */
	protected void sequence_ModuleDescriptionDesign(EObject context, ModuleDescriptionDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID task=[Task|ID] (included+=[Module|ID] included+=[Module|ID]*)? (required+=[Module|ID] required+=[Module|ID]*)?)
	 */
	protected void sequence_ModuleDescription(EObject context, ModuleDescription semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID descriptor=DescriptoModulerDesign realization=RealizationModuleDesign)
	 */
	protected void sequence_ModuleDesign(EObject context, ModuleDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__DESCRIPTOR) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__DESCRIPTOR));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__REALIZATION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_DESIGN__REALIZATION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getModuleDesignAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getModuleDesignAccess().getDescriptorDescriptoModulerDesignParserRuleCall_3_0(), semanticObject.getDescriptor());
		feeder.accept(grammarAccess.getModuleDesignAccess().getRealizationRealizationModuleDesignParserRuleCall_4_0(), semanticObject.getRealization());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID label=STRING type=STRING)
	 */
	protected void sequence_ModuleParameter(EObject context, ModuleParameter semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__LABEL) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__LABEL));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__TYPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.MODULE_PARAMETER__TYPE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getModuleParameterAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getModuleParameterAccess().getLabelSTRINGTerminalRuleCall_4_0(), semanticObject.getLabel());
		feeder.accept(grammarAccess.getModuleParameterAccess().getTypeSTRINGTerminalRuleCall_6_0(), semanticObject.getType());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID module=[Module|ID] (modules+=[Module|ID] modules+=[Module|ID]*)?)
	 */
	protected void sequence_ModuleRealizationAdaptationPoint(EObject context, ModuleRealizationAdaptationPoint semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         solution=[Module|ID] 
	 *         (adaptationpoints+=[ModuleRealizationAdaptationPoint|ID] adaptationpoints+=[ModuleRealizationAdaptationPoint|ID]*)?
	 *     )
	 */
	protected void sequence_ModuleRealization(EObject context, ModuleRealization semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (md=[ModuleDesign|ID] mod=[Module|ID] domain=ActivityApplicationDomain targetName=STRING?)
	 */
	protected void sequence_ModuleRefiner(EObject context, ModuleRefiner semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID (parameters+=[ModuleParameter|ID] parameters+=[ModuleParameter|ID]*)? desc=[ModuleDescription|ID] implementation=STRING)
	 */
	protected void sequence_Module(EObject context, Module semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (classes+=[Class|ID] classes+=[Class|ID]*)?
	 */
	protected void sequence_ParameterDesign(EObject context, ParameterDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID descriptor=DescriptorDesign realization=RealizationDesgn)
	 */
	protected void sequence_ProcessArchitectureDesign(EObject context, ProcessArchitectureDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__DESCRIPTOR) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__DESCRIPTOR));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__REALIZATION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.PROCESS_ARCHITECTURE_DESIGN__REALIZATION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getProcessArchitectureDesignAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getProcessArchitectureDesignAccess().getDescriptorDescriptorDesignParserRuleCall_3_0(), semanticObject.getDescriptor());
		feeder.accept(grammarAccess.getProcessArchitectureDesignAccess().getRealizationRealizationDesgnParserRuleCall_4_0(), semanticObject.getRealization());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         (tasks+=[Task|ID] tasks+=[Task|ID]*)? 
	 *         (messages+=[MessageTask|ID] messages+=[MessageTask|ID]*)? 
	 *         (dataaccesses+=[DataAccess|ID] dataaccesses+=[DataAccess|ID]*)? 
	 *         (classes+=[Class|ID] classes+=[Class|ID]*)?
	 *     )
	 */
	protected void sequence_ProcessArchitecture(EObject context, ProcessArchitecture semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID task=[Task|ID] (tasks+=[Task|ID] tasks+=[Task|ID]*)?)
	 */
	protected void sequence_ProcessRealizationAdaptationPoint(EObject context, ProcessRealizationAdaptationPoint semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         solution=[ProcessArchitecture|ID] 
	 *         (adaptationpoints+=[ProcessRealizationAdaptationPoint|ID] adaptationpoints+=[ProcessRealizationAdaptationPoint|ID]*)?
	 *     )
	 */
	protected void sequence_ProcessRealization(EObject context, ProcessRealization semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (pa=[ProcessArchitectureDesign|ID] domain=TaskApplicationDomain targetName=STRING?)
	 */
	protected void sequence_ProcessRefiner(EObject context, ProcessRefiner semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID action=[Activity|ID] (classes+=[Class|ID] classes+=[Class|ID]*)? precision=STRING)
	 */
	protected void sequence_Process(EObject context, org.m2.formBcs.formBcs.Process semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (solution=SolutionDesign adaptationpoints=AdaptationPointDesign)
	 */
	protected void sequence_RealizationDesgn(EObject context, RealizationDesgn semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_DESGN__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_DESGN__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_DESGN__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_DESGN__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getRealizationDesgnAccess().getSolutionSolutionDesignParserRuleCall_2_0(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getRealizationDesgnAccess().getAdaptationpointsAdaptationPointDesignParserRuleCall_3_0(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (solution=SolutionModuleDesign adaptationpoints=AdaptationPointModuleDesign)
	 */
	protected void sequence_RealizationModuleDesign(EObject context, RealizationModuleDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_MODULE_DESIGN__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_MODULE_DESIGN__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_MODULE_DESIGN__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_MODULE_DESIGN__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getRealizationModuleDesignAccess().getSolutionSolutionModuleDesignParserRuleCall_2_0(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getRealizationModuleDesignAccess().getAdaptationpointsAdaptationPointModuleDesignParserRuleCall_3_0(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (solution=SolutionSubsystem adaptationpoints=AdaptationPointSubsystem)
	 */
	protected void sequence_RealizationSubsystem(EObject context, RealizationSubsystem semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_SUBSYSTEM__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_SUBSYSTEM__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REALIZATION_SUBSYSTEM__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REALIZATION_SUBSYSTEM__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getRealizationSubsystemAccess().getSolutionSolutionSubsystemParserRuleCall_2_0(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getRealizationSubsystemAccess().getAdaptationpointsAdaptationPointSubsystemParserRuleCall_3_0(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         conceptualarchitecture=[ConceptualArchitecture|ID] 
	 *         (processarchitectures+=[ProcessArchitecture|ID] processarchitectures+=[ProcessArchitecture|ID]*)? 
	 *         (modules+=[Module|ID] modules+=[Module|ID]*)?
	 *     )
	 */
	protected void sequence_ReferenceArchitecture(EObject context, ReferenceArchitecture semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         (modules+=[ModuleRealizationAdaptationPoint|ID] modules+=[ModuleRealizationAdaptationPoint|ID]*)? 
	 *         (tasks+=[ProcessRealizationAdaptationPoint|ID] tasks+=[ProcessRealizationAdaptationPoint|ID]*)? 
	 *         (subsytems+=[ConceptualRealizationAdaptationPoint|ID] subsytems+=[ConceptualRealizationAdaptationPoint|ID]*)?
	 *     )
	 */
	protected void sequence_ReferenceRealizationAdaptationPoint(EObject context, ReferenceRealizationAdaptationPoint semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID solution=[ReferenceArchitecture|ID] adaptationpoints=[ReferenceRealizationAdaptationPoint|ID])
	 */
	protected void sequence_ReferenceRealization(EObject context, ReferenceRealization semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REFERENCE_REALIZATION__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getReferenceRealizationAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getReferenceRealizationAccess().getSolutionReferenceArchitectureIDTerminalRuleCall_4_0_1(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getReferenceRealizationAccess().getAdaptationpointsReferenceRealizationAdaptationPointIDTerminalRuleCall_6_0_1(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID solution=STRING adaptationpoints=STRING)
	 */
	protected void sequence_ReusableComponentRealization(EObject context, ReusableComponentRealization semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__SOLUTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__SOLUTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__ADAPTATIONPOINTS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.REUSABLE_COMPONENT_REALIZATION__ADAPTATIONPOINTS));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getReusableComponentRealizationAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getReusableComponentRealizationAccess().getSolutionSTRINGTerminalRuleCall_4_0(), semanticObject.getSolution());
		feeder.accept(grammarAccess.getReusableComponentRealizationAccess().getAdaptationpointsSTRINGTerminalRuleCall_6_0(), semanticObject.getAdaptationpoints());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID action=[Task|ID] (classes+=[Class|ID] classes+=[Class|ID]*)? precision=STRING)
	 */
	protected void sequence_Rule(EObject context, Rule semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (subsystem=[SubSystem|ID] (subsystems+=[SubSystem|ID] subsystems+=[SubSystem|ID]*)*)
	 */
	protected void sequence_SSAdaptationDesign(EObject context, SSAdaptationDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         (tasks+=[Task|ID] tasks+=[Task|ID]*)? 
	 *         (classes+=[Class|ID] classes+=[Class|ID]*)? 
	 *         (dataaccess+=DataAccessDesign dataaccess+=DataAccessDesign*)? 
	 *         (messages+=MessageDesign messages+=MessageDesign*)?
	 *     )
	 */
	protected void sequence_SolutionDesign(EObject context, SolutionDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID parameters=ParameterDesign description=ModuleDescriptionDesign implementation=STRING)
	 */
	protected void sequence_SolutionModuleDesign(EObject context, SolutionModuleDesign semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__PARAMETERS) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__PARAMETERS));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__DESCRIPTION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__DESCRIPTION));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__IMPLEMENTATION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SOLUTION_MODULE_DESIGN__IMPLEMENTATION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getSolutionModuleDesignAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getSolutionModuleDesignAccess().getParametersParameterDesignParserRuleCall_3_0(), semanticObject.getParameters());
		feeder.accept(grammarAccess.getSolutionModuleDesignAccess().getDescriptionModuleDescriptionDesignParserRuleCall_4_0(), semanticObject.getDescription());
		feeder.accept(grammarAccess.getSolutionModuleDesignAccess().getImplementationSTRINGTerminalRuleCall_6_0(), semanticObject.getImplementation());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     ((subsystems+=[SubSystem|ID] subsystems+=[SubSystem|ID]*)? (links+=LinkSSA links+=LinkSSA*)?)
	 */
	protected void sequence_SolutionSubsystem(EObject context, SolutionSubsystem semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (ssa=[SubsystemArchitecture|ID] ss=[SubSystem|ID] domain=ApplicationDomain targetName=STRING?)
	 */
	protected void sequence_SubSystemRefiner(EObject context, SubSystemRefiner semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID (features+=[Feature|ID] features+=[Feature|ID]*)?)
	 */
	protected void sequence_SubSystem(EObject context, SubSystem semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID descriptor=DescriptorDesignSSA realization=RealizationSubsystem)
	 */
	protected void sequence_SubsystemArchitecture(EObject context, SubsystemArchitecture semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__NAME));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__DESCRIPTOR) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__DESCRIPTOR));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__REALIZATION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.SUBSYSTEM_ARCHITECTURE__REALIZATION));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getSubsystemArchitectureAccess().getNameIDTerminalRuleCall_2_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getSubsystemArchitectureAccess().getDescriptorDescriptorDesignSSAParserRuleCall_4_0(), semanticObject.getDescriptor());
		feeder.accept(grammarAccess.getSubsystemArchitectureAccess().getRealizationRealizationSubsystemParserRuleCall_5_0(), semanticObject.getRealization());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (task=[Task|ID] tasks+=[Task|ID] tasks+=[Task|ID]*)
	 */
	protected void sequence_TaskAdaptationPointDesign(EObject context, TaskAdaptationPointDesign semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         targetTask=[Task|ID] 
	 *         (common+=[Action|ID] common+=[Action|ID]*)? 
	 *         (optional+=[Action|ID] optional+=[Action|ID]*)? 
	 *         (variabilities+=[ActionVariability|ID] variabilities+=[ActionVariability|ID]*)?
	 *     )
	 */
	protected void sequence_TaskApplicationDomain(EObject context, TaskApplicationDomain semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID tasks+=[Task|ID] tasks+=[Task|ID]*)
	 */
	protected void sequence_TaskVariability(EObject context, TaskVariability semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         is_transient=Boolean? 
	 *         (common+=[Action|ID] common+=[Action|ID]*)? 
	 *         (optional+=[Action|ID] optional+=[Action|ID]*)? 
	 *         (variabilities+=[ActionVariability|ID] variabilities+=[ActionVariability|ID]*)?
	 *     )
	 */
	protected void sequence_Task(EObject context, Task semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (fbc=[FeatureBusinessComponent|ID] domain=ApplicationDomain targetName=STRING?)
	 */
	protected void sequence_VerticalRefiner(EObject context, VerticalRefiner semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (featureRefined+=VerticalRefiner* subsystemRefined+=SubSystemRefiner* processRefined+=ProcessRefiner* moduleRefines+=ModuleRefiner*)
	 */
	protected void sequence_Vertical(EObject context, Vertical semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (type=[Class|ID] name=ID)
	 */
	protected void sequence_methodParameter(EObject context, methodParameter semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.METHOD_PARAMETER__TYPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.METHOD_PARAMETER__TYPE));
			if(transientValues.isValueTransient(semanticObject, FormBcsPackage.Literals.METHOD_PARAMETER__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FormBcsPackage.Literals.METHOD_PARAMETER__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getMethodParameterAccess().getTypeClassIDTerminalRuleCall_0_0_1(), semanticObject.getType());
		feeder.accept(grammarAccess.getMethodParameterAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
}
