package org.m2.formBcs.util;

import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class FormBcsUtil {
  private /* FormBcsFactory */Object fabrique /* Skipped initializer because of errors */;
  
  public static /* ArrayList<Feature> */Object featureUnion(final /* List<Feature> */Object A, final /* List<Feature> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Feature> */Object featureIntersection(final /* List<Feature> */Object A, final /* List<Feature> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type.");
  }
  
  public static ArrayList<Class> classUnion(final List<Class> A, final List<Class> B) {
    ArrayList<Class> _xblockexpression = null;
    {
      A.addAll(B);
      final ArrayList<Class> retour = CollectionLiterals.<Class>newArrayList(((Class[])Conversions.unwrapArray(A, Class.class)));
      _xblockexpression = retour;
    }
    return _xblockexpression;
  }
  
  public static ArrayList<Class> classIntersection(final List<Class> A, final List<Class> B) {
    ArrayList<Class> _xblockexpression = null;
    {
      Iterable<Class> _plus = Iterables.<Class>concat(A, B);
      final Function1<Class, Boolean> _function = new Function1<Class, Boolean>() {
        public Boolean apply(final Class it) {
          boolean _and = false;
          boolean _contains = A.contains(it);
          if (!_contains) {
            _and = false;
          } else {
            boolean _contains_1 = B.contains(it);
            _and = _contains_1;
          }
          return Boolean.valueOf(_and);
        }
      };
      Iterable<Class> _filter = IterableExtensions.<Class>filter(_plus, _function);
      List<Class> _list = IterableExtensions.<Class>toList(_filter);
      final ArrayList<Class> retour = CollectionLiterals.<Class>newArrayList(((Class[])Conversions.unwrapArray(_list, Class.class)));
      _xblockexpression = retour;
    }
    return _xblockexpression;
  }
  
  public static /* List<Feature> */Object featureleafs(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nisEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nfeatureleafs cannot be resolved"
      + "\nisEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  public static /* List<Feature> */Object featurefragments(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\nThere is no context to infer the closure\'s argument types from. Consider typing the arguments or put the closures into a typed context."
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nisEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nfeaturefragments cannot be resolved"
      + "\nisEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  public static /* List<Feature> */Object realization(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nfeatureIntersection cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nequals cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\n|| cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n&& cannot be resolved"
      + "\noptional cannot be resolved"
      + "\nfeatureIntersection cannot be resolved"
      + "\noptional cannot be resolved"
      + "\nequals cannot be resolved"
      + "\noptional cannot be resolved"
      + "\n|| cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ntest cannot be resolved"
      + "\n== cannot be resolved");
  }
  
  private static boolean test(final /* Feature */Object f, final /* Feature */Object g) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nvariabilities cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n== cannot be resolved");
  }
  
  public static Object isAbstracFeature(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nfeatureDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved");
  }
  
  public static /* List<Feature> */Object instanciate(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\nisAbstracFeature cannot be resolved"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nverb cannot be resolved"
      + "\n== cannot be resolved"
      + "\nverb cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\n== cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  public static Object equivalentFeature(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\n== cannot be resolved"
      + "\nfeatureDecomposition cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\n== cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ngeneralization cannot be resolved"
      + "\n== cannot be resolved"
      + "\ngeneralization cannot be resolved");
  }
  
  public static Object collaborate(final /* Feature */Object f, final /* Feature */Object g) {
    throw new Error("Unresolved compilation problems:"
      + "\nclasses cannot be resolved"
      + "\nclassIntersection cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n>= cannot be resolved");
  }
  
  public static /* List<Feature> */Object joinFeatureVariabilities(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nvariabilities cannot be resolved"
      + "\nfeatures cannot be resolved");
  }
  
  public static /* List<Task> */Object joinActivityVariabilities(final /* Activity */Object a) {
    throw new Error("Unresolved compilation problems:"
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nvariabilities cannot be resolved"
      + "\ntasks cannot be resolved");
  }
  
  public static /* List<Action> */Object joinTaskVariabilities(final /* Task */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nvariabilities cannot be resolved"
      + "\nactions cannot be resolved");
  }
  
  public static /* ArrayList<Feature> */Object featureDecomposition(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\ngeneralization cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\noptional cannot be resolved"
      + "\njoinFeatureVariabilities cannot be resolved");
  }
  
  public static /* List<Task> */Object activityDecomposition(final /* Activity */Object a) {
    throw new Error("Unresolved compilation problems:"
      + "\nTask cannot be resolved to a type."
      + "\ncommon cannot be resolved"
      + "\noptional cannot be resolved"
      + "\njoinActivityVariabilities cannot be resolved");
  }
  
  public static /* List<Action> */Object taskDecomposition(final /* Task */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\n== cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\noptional cannot be resolved"
      + "\njoinTaskVariabilities cannot be resolved");
  }
  
  public static /* List<Feature> */Object conceptualArchitectureDecomposition(final /* ConceptualArchitecture */Object ca) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nsubsystems cannot be resolved"
      + "\nfeatures cannot be resolved");
  }
  
  public static Object conceptualArchitectures(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nConceptualArchitecture cannot be resolved to a type."
      + "\nConceptualArchitecture cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nconceptualArchitectureDecomposition cannot be resolved"
      + "\ntoSet cannot be resolved"
      + "\nequals cannot be resolved"
      + "\nrealization cannot be resolved"
      + "\ntoSet cannot be resolved");
  }
  
  public static /* List<SubSystem> */Object ssImplement(final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfeatureHasSSImplement cannot be resolved");
  }
  
  private static boolean featureHasSSImplement(final /* SubSystem */Object ss1, final /* SubSystem */Object ss2) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nfeatures cannot be resolved"
      + "\nrealization cannot be resolved"
      + "\nfeatures cannot be resolved");
  }
  
  public static /* ArrayList<Action> */Object actionUnion(final /* List<Action> */Object A, final /* List<Action> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nAction cannot be resolved to a type.");
  }
  
  public static /* List<Action> */Object actionIntersection(final /* List<Action> */Object A, final /* List<Action> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type."
      + "\nAction cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object activityUnion(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object activityIntersection(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* List<Task> */Object taskUnion(final /* List<Task> */Object A, final /* List<Task> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Task> */Object taskIntersection(final /* List<Task> */Object A, final /* List<Task> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nTask cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object taskVairabilityUnion(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object taskVariabilityIntersection(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object activityVariabilityUnion(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* ArrayList<Activity> */Object activityVariabilityàIntersection(final /* List<Activity> */Object A, final /* List<Activity> */Object B) {
    throw new Error("Unresolved compilation problems:"
      + "\nActivity cannot be resolved to a type.");
  }
  
  public static /* List<ProcessArchitecture> */Object processArchitectures(final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nProcessArchitecture cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nsubsystemAndProcessArchitecture cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nmessageAndProcessArchitecture cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ndataAccessAndProcessArchitecture cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nclassProcessArchitecture cannot be resolved");
  }
  
  public static /* List<Task> */Object pImplement(final /* Task */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nTask cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nactionIntersection cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nequals cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\n|| cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n&& cannot be resolved"
      + "\noptional cannot be resolved"
      + "\nactionIntersection cannot be resolved"
      + "\noptional cannot be resolved"
      + "\nequals cannot be resolved"
      + "\noptional cannot be resolved"
      + "\n|| cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ntest2 cannot be resolved"
      + "\n== cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  private static boolean test2(final /* Task */Object f, final /* Task */Object g) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nvariabilities cannot be resolved"
      + "\nactions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ncommon cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n== cannot be resolved");
  }
  
  private static boolean subsystemAndProcessArchitecture(final /* ProcessArchitecture */Object pa, final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\ntasks cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nverb cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n== cannot be resolved");
  }
  
  private static boolean messageAndProcessArchitecture(final /* ProcessArchitecture */Object pa) {
    throw new Error("Unresolved compilation problems:"
      + "\nmessages cannot be resolved"
      + "\nfield cannot be resolved"
      + "\ntask1 cannot be resolved"
      + "\ntaskDecomposition cannot be resolved"
      + "\nactionIntersection cannot be resolved"
      + "\nfield cannot be resolved"
      + "\ntask2 cannot be resolved"
      + "\ntaskDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  private static boolean dataAccessAndProcessArchitecture(final /* ProcessArchitecture */Object pa, final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\ndataaccesses cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nverb cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\ntask cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\nclass cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n== cannot be resolved");
  }
  
  private static boolean classProcessArchitecture(final /* ProcessArchitecture */Object pa, final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nclasses cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved");
  }
  
  public static Object module(final /* Task */Object t) {
    throw new Error("Unresolved compilation problems:"
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\n== cannot be resolved"
      + "\ndesc cannot be resolved"
      + "\ntask cannot be resolved"
      + "\nget cannot be resolved"
      + "\n?: cannot be resolved");
  }
  
  public static /* List<Module> */Object moduleImplement(final /* Module */Object m) {
    throw new Error("Unresolved compilation problems:"
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ndesc cannot be resolved"
      + "\ntask cannot be resolved"
      + "\npImplement cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\ndesc cannot be resolved"
      + "\ntask cannot be resolved");
  }
  
  public static Object refine(final /* Context */Object c) {
    throw new Error("Unresolved compilation problems:"
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nContext cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n== cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nget cannot be resolved"
      + "\n?: cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n== cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\ncontainsAll cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nget cannot be resolved"
      + "\n?: cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n== cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\ncontainsAll cannot be resolved"
      + "\nprocesses cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nrules cannot be resolved"
      + "\ncontainsAll cannot be resolved"
      + "\nrules cannot be resolved"
      + "\n! cannot be resolved"
      + "\nget cannot be resolved"
      + "\n?: cannot be resolved");
  }
  
  public static /* List<SubSystem> */Object buildCASubsytem(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nFormBcsFactory cannot be resolved to a type."
      + "\nfeatureDecomposition cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n>= cannot be resolved"
      + "\ncontainsCollaborator cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateSubSystem cannot be resolved"
      + "\nname cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nadd cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\ncontainsCollaborator cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nadd cannot be resolved");
  }
  
  public static /* List<Link> */Object buildLinks(final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nLink cannot be resolved to a type."
      + "\nLink cannot be resolved to a type."
      + "\nLink cannot be resolved to a type."
      + "\nFormBcsFactory cannot be resolved to a type."
      + "\nbuildCASubsytem cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\n!= cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nallFeatureDecomposition cannot be resolved"
      + "\nfeatureIntersection cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nallFeatureDecomposition cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n>= cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateLink cannot be resolved"
      + "\nsubsystem1 cannot be resolved"
      + "\nsubsystem2 cannot be resolved");
  }
  
  public static /* List<SubSystem> */Object subsystemRealization(final /* SubSystem */Object ss) {
    throw new Error("Unresolved compilation problems:"
      + "\nSubSystem cannot be resolved to a type."
      + "\nSubSystem cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFormBcsFactory cannot be resolved to a type."
      + "\nFormBcsFactory cannot be resolved to a type."
      + "\nfeatures cannot be resolved"
      + "\nrealization cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateSubSystem cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nadd cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateSubSystem cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nadd cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\naddAll cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nname cannot be resolved"
      + "\nname cannot be resolved"
      + "\n+ cannot be resolved"
      + "\n+ cannot be resolved");
  }
  
  private static Object buildSubsytemAdapatationPoint(final /* SubSystem */Object ss, final /* FeatureBusinessComponent */Object fbc) {
    throw new Error("Unresolved compilation problems:"
      + "\nFormBcsFactory cannot be resolved to a type."
      + "\neINSTANCE cannot be resolved"
      + "\ncreateConceptualRealizationAdaptationPoint cannot be resolved"
      + "\nsubsystems cannot be resolved"
      + "\naddAll cannot be resolved"
      + "\nsubsystemRealization cannot be resolved"
      + "\nsubsystem cannot be resolved"
      + "\nname cannot be resolved"
      + "\nname cannot be resolved"
      + "\n+ cannot be resolved");
  }
  
  public static /* List<ConceptualRealizationAdaptationPoint> */Object buildAllAdaptationPoint(final /* List<SubSystem> */Object subsystems, final /* FeatureBusinessComponent */Object fbc) {
    throw new Error("Unresolved compilation problems:"
      + "\nConceptualRealizationAdaptationPoint cannot be resolved to a type."
      + "\nConceptualRealizationAdaptationPoint cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nrealization cannot be resolved"
      + "\nadaptationpoints cannot be resolved"
      + "\nadaptationpoints cannot be resolved"
      + "\nfeature cannot be resolved"
      + "\nfeatures cannot be resolved"
      + "\nfeatureIntersection cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\nbuildSubsytemAdapatationPoint cannot be resolved"
      + "\nname cannot be resolved"
      + "\nname cannot be resolved"
      + "\n+ cannot be resolved"
      + "\n+ cannot be resolved"
      + "\nbuildSubsytemAdapatationPoint cannot be resolved");
  }
  
  private static boolean containsCollaborator(final /* SubSystem */Object ss, final /* Feature */Object f) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nfeatures cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\ncollaborate cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n!= cannot be resolved");
  }
  
  private static /* ArrayList<Feature> */Object allFeatureDecomposition(final /* List<Feature> */Object features) {
    throw new Error("Unresolved compilation problems:"
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\nFeature cannot be resolved to a type."
      + "\ncommon cannot be resolved"
      + "\noptional cannot be resolved"
      + "\njoinFeatureVariabilities cannot be resolved");
  }
  
  public static /* List<DataAccess> */Object buildDataAccess(final /* org.m2.formBcs.formBcs.Process */Object p) {
    throw new Error("Unresolved compilation problems:"
      + "\nDataAccess cannot be resolved to a type."
      + "\nDataAccess cannot be resolved to a type."
      + "\nClassMethod cannot be resolved to a type."
      + "\nFormBcsFactory.eINSTANCE cannot be resolved to a type."
      + "\naction cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\nclasses cannot be resolved"
      + "\nmembers cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\nname cannot be resolved"
      + "\n== cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n== cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateDataAccess cannot be resolved"
      + "\ntask cannot be resolved"
      + "\nclasse cannot be resolved");
  }
  
  public static /* List<MessageTask> */Object buildMessages(final /* org.m2.formBcs.formBcs.Process */Object p) {
    throw new Error("Unresolved compilation problems:"
      + "\nMessageTask cannot be resolved to a type."
      + "\nMessageTask cannot be resolved to a type."
      + "\nFormBcsFactory.eINSTANCE cannot be resolved to a type."
      + "\naction cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\naction cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\n!= cannot be resolved"
      + "\n&& cannot be resolved"
      + "\ntaskDecomposition cannot be resolved"
      + "\nactionIntersection cannot be resolved"
      + "\ntaskDecomposition cannot be resolved"
      + "\nisNullOrEmpty cannot be resolved"
      + "\n! cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateMessageTask cannot be resolved"
      + "\nfield cannot be resolved"
      + "\ntask1 cannot be resolved"
      + "\nfield cannot be resolved"
      + "\ntask2 cannot be resolved");
  }
  
  public static /* List<ProcessRealizationAdaptationPoint> */Object buildProcessArchitectureAdaptationPoints(final /* org.m2.formBcs.formBcs.Process */Object p) {
    throw new Error("Unresolved compilation problems:"
      + "\nProcessRealizationAdaptationPoint cannot be resolved to a type."
      + "\nProcessRealizationAdaptationPoint cannot be resolved to a type."
      + "\nFormBcsFactory.eINSTANCE cannot be resolved to a type."
      + "\naction cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\npImplement cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n>= cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateProcessRealizationAdaptationPoint cannot be resolved"
      + "\ntask cannot be resolved"
      + "\ntasks cannot be resolved"
      + "\naddAll cannot be resolved");
  }
  
  public static String subsystemAdaptationPointToString(final /* List<ConceptualRealizationAdaptationPoint> */Object liste) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field name is undefined for the type FormBcsUtil"
      + "\nname cannot be resolved"
      + "\nsubsystem cannot be resolved"
      + "\nname cannot be resolved"
      + "\nsubsystems cannot be resolved"
      + "\nmap cannot be resolved"
      + "\njoin cannot be resolved");
  }
  
  public static /* List<ModuleRealizationAdaptationPoint> */Object buildModuleAdaptationPoint(final /* Task */Object t, final /* HorizontalModuleDesign */Object hmd) {
    throw new Error("Unresolved compilation problems:"
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModuleRealizationAdaptationPoint cannot be resolved to a type."
      + "\nModuleRealizationAdaptationPoint cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nModule cannot be resolved to a type."
      + "\nThe method or field Model is undefined for the type FormBcsUtil"
      + "\nFormBcsFactory.eINSTANCE cannot be resolved to a type."
      + "\ngetContainerOfType cannot be resolved"
      + "\ndefinitions cannot be resolved"
      + "\nfilter cannot be resolved"
      + "\npass cannot be resolved"
      + "\ndescriptor cannot be resolved"
      + "\ncontext cannot be resolved"
      + "\ndomain cannot be resolved"
      + "\naction cannot be resolved"
      + "\nactivityDecomposition cannot be resolved"
      + "\ncontains cannot be resolved"
      + "\ndesc cannot be resolved"
      + "\ntask cannot be resolved"
      + "\nimplementation cannot be resolved"
      + "\n!= cannot be resolved"
      + "\nmoduleImplement cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n!= cannot be resolved"
      + "\neINSTANCE cannot be resolved"
      + "\ncreateModuleRealizationAdaptationPoint cannot be resolved"
      + "\nmodule cannot be resolved"
      + "\nmodules cannot be resolved"
      + "\naddAll cannot be resolved");
  }
}
